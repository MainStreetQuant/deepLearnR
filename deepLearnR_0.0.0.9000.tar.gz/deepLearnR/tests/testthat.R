library(testthat)
library(deepLearnR)

test_check("deepLearnR")
